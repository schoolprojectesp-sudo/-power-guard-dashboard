POWER GUARD 2.0 WEB DASHBOARD DEMO
Home: CONSUMER1001 / home123
KSEB: KSEB_ADMIN / kseb123
Open index.html in a web browser, or upload this folder to a static web host.
The displayed electrical readings are DEMO values until the ESP32/cloud API is connected.
KSEB power-cut is simulation-only.
